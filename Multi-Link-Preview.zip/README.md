# How to configure this project
```
virtualenv venv
env\Scripts\activate
npm install tailwindcss
npx tailwindcss init
``` 